import Header from "../Components/Header.jsx";
import Footer from "../Components/Footer.jsx";

const Home = () =>{
    return(
    <div>
        <div className="header-container">
            <Header/>
        </div>
            <div>
                    ddd
            </div>
        <div className="footer-container">
            <Footer/>
        </div>
    </div>
    )
}

export default Home;