import "../Styles/Components/Footer.scss";


const Footer = () =>{
    return(
        <div>d</div>
    )
}

export default Footer;